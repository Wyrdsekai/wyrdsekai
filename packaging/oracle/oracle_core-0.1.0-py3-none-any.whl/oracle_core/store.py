"""Model and event persistence.

Stores events, trained models, predictions, and feedback on the filesystem.
Per-user isolation. Models are lightweight (KB-scale for scikit-learn).

Storage layout:
    {base_dir}/
        events/
            {user_id}.jsonl          # append-only event log
        models/
            {user_id}/
                pattern_detector.pkl
                anomaly_detector.pkl
                ...
        predictions/
            {user_id}.jsonl          # prediction log
        feedback/
            {user_id}.jsonl          # feedback log
"""

from __future__ import annotations

import json
import os
import pickle
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Lock
from typing import Any, Generator

from .models import Event, Prediction, Feedback


class OracleStore:
    """Filesystem-backed persistence for oracle-core.

    Thread-safe: uses per-file locks for concurrent access from Flask server.
    """

    _locks: dict[str, Lock] = {}
    _global_lock = Lock()

    def __init__(self, base_dir: str = "~/.oracle-core"):
        self.base_dir = Path(os.path.expanduser(base_dir))
        self.base_dir.mkdir(parents=True, exist_ok=True)
        (self.base_dir / "events").mkdir(exist_ok=True)
        (self.base_dir / "models").mkdir(exist_ok=True)
        (self.base_dir / "predictions").mkdir(exist_ok=True)
        (self.base_dir / "feedback").mkdir(exist_ok=True)

    @contextmanager
    def _file_lock(self, path: Path) -> Generator[None, None, None]:
        """Per-file lock for thread-safe writes."""
        key = str(path)
        with self._global_lock:
            if key not in self._locks:
                self._locks[key] = Lock()
            lock = self._locks[key]
        with lock:
            yield

    # ── Events ────────────────────────────────────────────────────────

    def append_events(self, user_id: str, events: list[Event]) -> int:
        """Append events to the user's event log. Returns count appended."""
        path = self.base_dir / "events" / f"{user_id}.jsonl"
        with self._file_lock(path):
            with open(path, "a") as f:
                for event in events:
                    f.write(json.dumps(_event_to_dict(event)) + "\n")
        return len(events)

    def load_events(
        self,
        user_id: str,
        since: datetime | None = None,
        source: str | None = None,
        limit: int = 0,
    ) -> list[Event]:
        """Load events from the user's log, optionally filtered."""
        path = self.base_dir / "events" / f"{user_id}.jsonl"
        if not path.exists():
            return []

        events = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    event = _dict_to_event(d)
                    if since and _compare_timestamps(event.timestamp, since) < 0:
                        continue
                    if source and event.source != source:
                        continue
                    events.append(event)
                    if limit and len(events) >= limit:
                        break
                except (json.JSONDecodeError, KeyError):
                    continue

        return events

    def event_count(self, user_id: str) -> int:
        """Count events for a user (line count of JSONL file)."""
        path = self.base_dir / "events" / f"{user_id}.jsonl"
        if not path.exists():
            return 0
        with open(path) as f:
            return sum(1 for _ in f)

    # ── Models ────────────────────────────────────────────────────────

    def save_model(self, user_id: str, model_name: str, model: Any) -> None:
        """Pickle a trained model to disk."""
        model_dir = self.base_dir / "models" / user_id
        model_dir.mkdir(parents=True, exist_ok=True)
        path = model_dir / f"{model_name}.pkl"
        with open(path, "wb") as f:
            pickle.dump(model, f)

    def load_model(self, user_id: str, model_name: str) -> Any | None:
        """Load a pickled model, or None if not found."""
        path = self.base_dir / "models" / user_id / f"{model_name}.pkl"
        if not path.exists():
            return None
        with open(path, "rb") as f:
            return pickle.load(f)

    # ── Predictions ───────────────────────────────────────────────────

    def save_predictions(self, user_id: str, predictions: list[Prediction]) -> None:
        """Append predictions to the user's log."""
        path = self.base_dir / "predictions" / f"{user_id}.jsonl"
        with self._file_lock(path):
            with open(path, "a") as f:
                for pred in predictions:
                    f.write(json.dumps(_prediction_to_dict(pred)) + "\n")

    def load_predictions(self, user_id: str, limit: int = 50) -> list[Prediction]:
        """Load recent predictions."""
        path = self.base_dir / "predictions" / f"{user_id}.jsonl"
        if not path.exists():
            return []

        # Read last N lines (predictions are append-only, newest at end)
        lines = []
        with open(path) as f:
            for line in f:
                lines.append(line.strip())
                if len(lines) > limit:
                    lines.pop(0)

        return [_dict_to_prediction(json.loads(line)) for line in lines if line]

    # ── Retention ─────────────────────────────────────────────────────

    def compact_events(self, user_id: str, keep_days: int = 90) -> int:
        """Remove events older than keep_days. Returns count removed."""
        path = self.base_dir / "events" / f"{user_id}.jsonl"
        if not path.exists():
            return 0

        cutoff = datetime.now(timezone.utc) - timedelta(days=keep_days)
        kept = []
        removed = 0

        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    ts = datetime.fromisoformat(d["timestamp"])
                    if ts >= cutoff:
                        kept.append(line)
                    else:
                        removed += 1
                except (json.JSONDecodeError, KeyError):
                    kept.append(line)  # keep unparseable lines

        # Rewrite file
        with open(path, "w") as f:
            for line in kept:
                f.write(line + "\n")

        return removed

    def compact_predictions(self, user_id: str, keep_last: int = 200) -> int:
        """Keep only the last N predictions. Returns count removed."""
        path = self.base_dir / "predictions" / f"{user_id}.jsonl"
        if not path.exists():
            return 0

        lines = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    lines.append(line)

        if len(lines) <= keep_last:
            return 0

        removed = len(lines) - keep_last
        with open(path, "w") as f:
            for line in lines[-keep_last:]:
                f.write(line + "\n")

        return removed

    def purge_user(self, user_id: str) -> None:
        """Delete all data for a user."""
        import shutil
        for subdir in ["events", "predictions", "feedback"]:
            path = self.base_dir / subdir / f"{user_id}.jsonl"
            if path.exists():
                path.unlink()
        model_dir = self.base_dir / "models" / user_id
        if model_dir.exists():
            shutil.rmtree(model_dir)

    def disk_usage(self, user_id: str) -> dict[str, int]:
        """Return byte sizes for each data type."""
        sizes: dict[str, int] = {}
        for subdir in ["events", "predictions", "feedback"]:
            path = self.base_dir / subdir / f"{user_id}.jsonl"
            sizes[subdir] = path.stat().st_size if path.exists() else 0
        model_dir = self.base_dir / "models" / user_id
        if model_dir.exists():
            sizes["models"] = sum(f.stat().st_size for f in model_dir.iterdir() if f.is_file())
        else:
            sizes["models"] = 0
        sizes["total"] = sum(sizes.values())
        return sizes

    # ── Feedback ──────────────────────────────────────────────────────

    def save_feedback(self, user_id: str, feedback: Feedback) -> None:
        """Append feedback to the user's log."""
        path = self.base_dir / "feedback" / f"{user_id}.jsonl"
        with self._file_lock(path):
            with open(path, "a") as f:
                f.write(json.dumps({
                    "prediction_id": feedback.prediction_id,
                    "outcome": feedback.outcome.value,
                    "user_engaged": feedback.user_engaged,
                    "timestamp": feedback.timestamp.isoformat(),
                }) + "\n")


# ── Serialization helpers ────────────────────────────────────────────────────


def _compare_timestamps(a: datetime, b: datetime) -> int:
    """Compare two datetimes, handling mixed naive/aware gracefully."""
    # Strip timezone info for comparison if one is naive and one is aware
    if a.tzinfo is None and b.tzinfo is not None:
        b = b.replace(tzinfo=None)
    elif a.tzinfo is not None and b.tzinfo is None:
        a = a.replace(tzinfo=None)
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


def _event_to_dict(event: Event) -> dict:
    return {
        "timestamp": event.timestamp.isoformat(),
        "source": event.source,
        "event_type": event.event_type,
        "content": event.content,
        "metadata": event.metadata,
        "entity_id": event.entity_id,
        "room_id": event.room_id,
        "numeric_value": event.numeric_value,
        "tags": event.tags,
    }


def _dict_to_event(d: dict) -> Event:
    return Event(
        timestamp=datetime.fromisoformat(d["timestamp"]),
        source=d.get("source", ""),
        event_type=d.get("event_type", ""),
        content=d.get("content", ""),
        metadata=d.get("metadata", {}),
        entity_id=d.get("entity_id", ""),
        room_id=d.get("room_id", ""),
        numeric_value=d.get("numeric_value"),
        tags=d.get("tags", []),
    )


def _prediction_to_dict(pred: Prediction) -> dict:
    return {
        "id": pred.id,
        "text": pred.text,
        "category": pred.category.value,
        "confidence": pred.confidence,
        "evidence": pred.evidence,
        "actionable": pred.actionable,
        "created_at": pred.created_at.isoformat(),
        "expires_at": pred.expires_at.isoformat() if pred.expires_at else None,
    }


def _dict_to_prediction(d: dict) -> Prediction:
    return Prediction(
        id=d["id"],
        text=d["text"],
        category=PredictionCategory(d["category"]),
        confidence=d["confidence"],
        evidence=d.get("evidence", ""),
        actionable=d.get("actionable", False),
        created_at=datetime.fromisoformat(d["created_at"]) if d.get("created_at") else datetime.now(timezone.utc),
        expires_at=datetime.fromisoformat(d["expires_at"]) if d.get("expires_at") else None,
    )


# Deferred to the bottom of the module on purpose: importing this at the top
# creates a circular import with .models. noqa rather than restructure.
from .models import PredictionCategory  # noqa: E402
