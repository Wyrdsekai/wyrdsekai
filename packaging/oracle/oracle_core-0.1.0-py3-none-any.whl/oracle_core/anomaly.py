"""Anomaly detection on event streams and time series.

Detects unusual patterns: breaks in routine, volume spikes, gaps,
unexpected values. Uses Isolation Forest for multivariate anomaly
and statistical methods for time series anomalies.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

import numpy as np
from sklearn.ensemble import IsolationForest

from .i18n import t
from .models import Prediction, PredictionCategory


class AnomalyDetector:
    """Detects anomalies in event streams and time series."""

    # Minimum data before activation
    MIN_POINTS = 30

    def __init__(self, contamination: float = 0.05):
        """
        Args:
            contamination: Expected fraction of anomalies (0.01-0.1).
                Lower = fewer, higher-confidence detections.
        """
        self.contamination = contamination

    def detect_time_series(
        self,
        timestamps: list[datetime],
        values: list[float],
        label: str = "activity",
    ) -> list[Prediction]:
        """Detect anomalies in a numerical time series.

        Uses z-score for simple anomalies and rolling window comparison
        for context-aware detection.
        """
        if len(values) < self.MIN_POINTS:
            return []

        arr = np.array(values, dtype=float)
        predictions = []

        # Method 1: Z-score on recent window vs historical baseline
        baseline = arr[:-7] if len(arr) > 7 else arr
        recent = arr[-7:] if len(arr) > 7 else arr

        mean, std = baseline.mean(), baseline.std()
        if std == 0:
            return []

        for i, (ts, val) in enumerate(zip(timestamps[-len(recent):], recent)):
            z = (val - mean) / std
            if abs(z) >= 2.5:
                severity = min(abs(z) / 4.0, 1.0)
                confidence = min(0.6 + severity * 0.3, 0.95)

                key = (
                    "oracle.anomaly.spike" if z > 0
                    else "oracle.anomaly.drop"
                )
                ap = {
                    "label": label,
                    "value": f"{val:.1f}",
                    "mean": f"{mean:.1f}",
                    "std": f"{std:.1f}",
                    "z": f"{z:.1f}",
                }
                predictions.append(Prediction(
                    id=f"anomaly-zscore-{uuid.uuid4().hex[:8]}",
                    text=t(key, **ap),
                    text_key=key,
                    text_params=ap,
                    category=PredictionCategory.ANOMALY,
                    confidence=confidence,
                    evidence=f"Z-score={z:.2f}, baseline n={len(baseline)}, value={val:.2f}",
                ))

        # Method 2: Gap detection (missing data)
        predictions.extend(self._detect_gaps(timestamps, label))

        return predictions

    def detect_multivariate(
        self,
        feature_matrix: np.ndarray,
        timestamps: list[datetime],
        feature_names: list[str] | None = None,
        label: str = "activity",
    ) -> list[Prediction]:
        """Detect anomalies using Isolation Forest on feature vectors.

        Each row is a feature vector (e.g., from FeaturePipeline.extract_daily).
        Isolation Forest finds points that are easy to isolate = anomalous.
        """
        if len(feature_matrix) < self.MIN_POINTS:
            return []

        # Handle NaN/Inf
        matrix = np.nan_to_num(feature_matrix, nan=0.0, posinf=0.0, neginf=0.0)

        model = IsolationForest(
            contamination=self.contamination,
            random_state=42,
            n_estimators=100,
        )
        scores = model.fit_predict(matrix)
        raw_scores = model.decision_function(matrix)

        predictions = []
        for i, (label_val, score, ts) in enumerate(zip(scores, raw_scores, timestamps)):
            if label_val == -1:  # anomaly
                severity = max(0.0, -score)  # more negative = more anomalous
                confidence = min(0.6 + severity * 0.5, 0.95)

                # Find which features are most unusual for this point
                unusual_features = self._explain_anomaly(
                    matrix[i], matrix, feature_names
                )

                mp = {
                    "label": label,
                    "date": ts.strftime("%b %d"),
                    "details": unusual_features,
                }
                predictions.append(Prediction(
                    id=f"anomaly-iforest-{uuid.uuid4().hex[:8]}",
                    text=t("oracle.anomaly.multivariate", **mp),
                    text_key="oracle.anomaly.multivariate",
                    text_params=mp,
                    category=PredictionCategory.ANOMALY,
                    confidence=confidence,
                    evidence=(
                        f"Isolation Forest score={score:.3f}, "
                        f"contamination={self.contamination}"
                    ),
                ))

        return predictions

    def _detect_gaps(
        self, timestamps: list[datetime], label: str
    ) -> list[Prediction]:
        """Detect unusual gaps in the event stream."""
        if len(timestamps) < 10:
            return []

        # Calculate inter-event gaps
        sorted_ts = sorted(timestamps)
        gaps = [(sorted_ts[i + 1] - sorted_ts[i]).total_seconds() / 3600.0
                for i in range(len(sorted_ts) - 1)]

        if not gaps:
            return []

        gap_arr = np.array(gaps)
        mean_gap = gap_arr.mean()
        std_gap = gap_arr.std()

        if std_gap == 0:
            return []

        predictions = []

        # Check if the last gap (time since last event) is unusually large
        now = datetime.now(timezone.utc)
        last_gap = (now - sorted_ts[-1]).total_seconds() / 3600.0

        z = (last_gap - mean_gap) / std_gap
        if z >= 2.0 and last_gap > 12:  # at least 12 hours and unusual
            confidence = min(0.5 + (z - 2.0) * 0.15, 0.90)
            gp = {
                "label": label,
                "gap_hours": f"{last_gap:.0f}",
                "mean_hours": f"{mean_gap:.0f}",
            }
            predictions.append(Prediction(
                id=f"anomaly-gap-{uuid.uuid4().hex[:8]}",
                text=t("oracle.anomaly.gap", **gp),
                text_key="oracle.anomaly.gap",
                text_params=gp,
                category=PredictionCategory.ANOMALY,
                confidence=confidence,
                evidence=f"Current gap={last_gap:.1f}h, mean={mean_gap:.1f}h, z={z:.1f}",
            ))

        return predictions

    def _explain_anomaly(
        self,
        point: np.ndarray,
        matrix: np.ndarray,
        feature_names: list[str] | None,
    ) -> str:
        """Explain which features make a point anomalous."""
        means = matrix.mean(axis=0)
        stds = matrix.std(axis=0)
        stds[stds == 0] = 1.0  # avoid division by zero

        z_scores = (point - means) / stds
        top_indices = np.argsort(np.abs(z_scores))[-3:][::-1]

        explanations = []
        for idx in top_indices:
            if abs(z_scores[idx]) < 1.5:
                continue
            name = feature_names[idx] if feature_names and idx < len(feature_names) else f"feature_{idx}"
            direction = "high" if z_scores[idx] > 0 else "low"
            explanations.append(f"{name} unusually {direction}")

        return ", ".join(explanations) if explanations else "multiple features deviate from normal"
