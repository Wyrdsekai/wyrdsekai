"""Feedback and calibration system.

Tracks prediction outcomes and adjusts confidence thresholds.
The Oracle learns which types of predictions it's good at and
which it should be more conservative about.

This is the self-improvement loop:
  prediction → surfaced to user → outcome recorded → calibration updated
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from .models import Feedback, FeedbackOutcome


@dataclass
class CalibrationStats:
    """Accuracy stats for a prediction category."""

    total: int = 0
    correct: int = 0
    wrong: int = 0
    partial: int = 0
    ignored: int = 0
    engaged: int = 0  # user interacted with the prediction

    @property
    def accuracy(self) -> float:
        """Fraction of predictions that were correct (excluding ignored)."""
        evaluated = self.correct + self.wrong + self.partial
        if evaluated == 0:
            return 0.5  # prior — assume 50% when no data
        return (self.correct + self.partial * 0.5) / evaluated

    @property
    def engagement_rate(self) -> float:
        """Fraction of predictions that the user engaged with."""
        if self.total == 0:
            return 0.0
        return self.engaged / self.total

    @property
    def confidence_adjustment(self) -> float:
        """Multiplier to adjust reported confidence.

        If accuracy is 80%, predictions should be reported near their raw confidence.
        If accuracy is 30%, scale down confidence to be more conservative.
        """
        if self.total < 5:
            return 1.0  # not enough data to calibrate

        # Calibration: raw_confidence * adjustment → calibrated_confidence
        # accuracy > 0.7 → boost slightly (up to 1.1)
        # accuracy < 0.5 → dampen significantly (down to 0.6)
        acc = self.accuracy
        if acc >= 0.7:
            return min(1.0 + (acc - 0.7) * 0.33, 1.1)
        elif acc >= 0.5:
            return 1.0
        else:
            return max(0.6, 0.6 + (acc - 0.3) * 2.0)


class FeedbackCalibrator:
    """Tracks prediction outcomes and produces calibration adjustments."""

    def __init__(self):
        self.stats: dict[str, CalibrationStats] = defaultdict(CalibrationStats)

    def record(self, category: str, feedback: Feedback) -> None:
        """Record a feedback event."""
        s = self.stats[category]
        s.total += 1
        if feedback.user_engaged:
            s.engaged += 1

        match feedback.outcome:
            case FeedbackOutcome.CORRECT:
                s.correct += 1
            case FeedbackOutcome.WRONG:
                s.wrong += 1
            case FeedbackOutcome.PARTIAL:
                s.partial += 1
            case FeedbackOutcome.IGNORED:
                s.ignored += 1

    def get_adjustment(self, category: str) -> float:
        """Get confidence adjustment multiplier for a category."""
        if category in self.stats:
            return self.stats[category].confidence_adjustment
        return 1.0

    def calibrate_predictions(
        self, predictions: list, category_field: str = "category"
    ) -> list:
        """Apply calibration to a list of predictions, adjusting their confidence."""
        for pred in predictions:
            cat = getattr(pred, category_field, None)
            if cat:
                cat_str = cat.value if hasattr(cat, "value") else str(cat)
                adj = self.get_adjustment(cat_str)
                pred.confidence = min(pred.confidence * adj, 0.99)
        return predictions

    def summary(self) -> dict[str, dict]:
        """Return calibration summary for all categories."""
        return {
            cat: {
                "total": s.total,
                "accuracy": round(s.accuracy, 3),
                "engagement_rate": round(s.engagement_rate, 3),
                "confidence_adjustment": round(s.confidence_adjustment, 3),
            }
            for cat, s in self.stats.items()
        }
