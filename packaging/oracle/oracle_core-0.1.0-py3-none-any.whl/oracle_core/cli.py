"""oracle-core CLI — command-line interface for the prediction engine.

Usage:
    oracle-cli ingest USER_ID FILE.jsonl    Ingest events from JSONL
    oracle-cli train USER_ID                Run training cycle
    oracle-cli anticipate USER_ID           Get predictions
    oracle-cli patterns USER_ID             Detect patterns only
    oracle-cli anomalies USER_ID            Detect anomalies only
    oracle-cli forecast USER_ID             Forecast only
    oracle-cli topics USER_ID               Topic evolution only
    oracle-cli stats USER_ID                Show stats
    oracle-cli shell USER_ID                Interactive mode
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime

from .engine import Oracle
from .models import Event


def main():
    parser = argparse.ArgumentParser(
        prog="oracle-cli",
        description="oracle-core — personal prediction engine CLI",
    )
    parser.add_argument("--data-dir", default="~/.oracle-core", help="Data directory")
    parser.add_argument("--confidence", type=float, default=0.5, help="Min confidence threshold")

    sub = parser.add_subparsers(dest="command", required=True)

    # ingest
    p_ingest = sub.add_parser("ingest", help="Ingest events from JSONL file")
    p_ingest.add_argument("user_id")
    p_ingest.add_argument("file", help="JSONL file with events")

    # train
    p_train = sub.add_parser("train", help="Run training cycle")
    p_train.add_argument("user_id")

    # anticipate
    p_ant = sub.add_parser("anticipate", help="Get all predictions")
    p_ant.add_argument("user_id")

    # patterns
    p_pat = sub.add_parser("patterns", help="Detect patterns")
    p_pat.add_argument("user_id")

    # anomalies
    p_anom = sub.add_parser("anomalies", help="Detect anomalies")
    p_anom.add_argument("user_id")

    # forecast
    p_fc = sub.add_parser("forecast", help="Forecast")
    p_fc.add_argument("user_id")

    # topics
    p_top = sub.add_parser("topics", help="Topic evolution")
    p_top.add_argument("user_id")

    # stats
    p_stats = sub.add_parser("stats", help="Show stats")
    p_stats.add_argument("user_id")

    # shell
    p_shell = sub.add_parser("shell", help="Interactive mode")
    p_shell.add_argument("user_id")

    args = parser.parse_args()
    oracle = Oracle(data_dir=args.data_dir)

    if args.command == "ingest":
        count = 0
        with open(args.file) as f:
            events = []
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    events.append(Event(
                        timestamp=datetime.fromisoformat(d["timestamp"]),
                        source=d.get("source", ""),
                        event_type=d.get("event_type", ""),
                        content=d.get("content", ""),
                        metadata=d.get("metadata", {}),
                        entity_id=d.get("entity_id", ""),
                        room_id=d.get("room_id", ""),
                        numeric_value=d.get("numeric_value"),
                        tags=d.get("tags", []),
                    ))
                except (json.JSONDecodeError, KeyError) as e:
                    print(f"Skipping malformed line: {e}", file=sys.stderr)
            count = oracle.ingest(args.user_id, events)
        print(f"Ingested {count} events for user '{args.user_id}'")

    elif args.command == "train":
        result = oracle.train(args.user_id)
        print(json.dumps(result, indent=2, default=str))

    elif args.command == "anticipate":
        predictions = oracle.anticipate(args.user_id, min_confidence=args.confidence)
        _print_predictions(predictions)

    elif args.command == "patterns":
        predictions = oracle.analyze_patterns(args.user_id)
        _print_predictions(predictions)

    elif args.command == "anomalies":
        predictions = oracle.analyze_anomalies(args.user_id)
        _print_predictions(predictions)

    elif args.command == "forecast":
        predictions = oracle.analyze_forecast(args.user_id)
        _print_predictions(predictions)

    elif args.command == "topics":
        predictions = oracle.analyze_topics(args.user_id)
        _print_predictions(predictions)

    elif args.command == "stats":
        stats = oracle.stats(args.user_id)
        print(json.dumps(stats, indent=2))

    elif args.command == "shell":
        _interactive(oracle, args.user_id, args.confidence)


def _print_predictions(predictions):
    if not predictions:
        print("No predictions.")
        return
    for p in predictions:
        icon = {
            "pattern": "~", "anomaly": "!", "forecast": ">",
            "correlation": "<>", "topic": "#", "sequence": "->",
            "recommendation": "*", "anticipation": "**",
        }.get(p.category.value, "?")
        print(f"  {icon} [{p.confidence:.0%}] {p.text}")
        if p.evidence:
            print(f"         {p.evidence}")


def _interactive(oracle: Oracle, user_id: str, min_confidence: float):
    print(f"oracle-core shell — user: {user_id}")
    print("Commands: train, anticipate, patterns, anomalies, forecast, topics, stats, quit")
    print(f"Events: {oracle.stats(user_id).get('event_count', 0)}")
    print()

    while True:
        try:
            cmd = input("oracle> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if cmd in ("quit", "exit", "q"):
            break
        elif cmd == "train":
            result = oracle.train(user_id)
            print(json.dumps(result, indent=2, default=str))
        elif cmd == "anticipate":
            _print_predictions(oracle.anticipate(user_id, min_confidence=min_confidence))
        elif cmd == "patterns":
            _print_predictions(oracle.analyze_patterns(user_id))
        elif cmd == "anomalies":
            _print_predictions(oracle.analyze_anomalies(user_id))
        elif cmd == "forecast":
            _print_predictions(oracle.analyze_forecast(user_id))
        elif cmd == "topics":
            _print_predictions(oracle.analyze_topics(user_id))
        elif cmd == "stats":
            print(json.dumps(oracle.stats(user_id), indent=2))
        elif cmd == "help":
            print("Commands: train, anticipate, patterns, anomalies, forecast, topics, stats, quit")
        else:
            print(f"Unknown command: {cmd}. Type 'help'.")


if __name__ == "__main__":
    main()
