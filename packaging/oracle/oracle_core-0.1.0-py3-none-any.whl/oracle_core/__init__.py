"""oracle-core — personal prediction engine.

Pattern detection, anomaly detection, time series forecasting,
correlation discovery, topic evolution, behavioral sequences,
recommendations, and anticipatory synthesis from your own data.

Usage:
    from oracle_core import Oracle
    from oracle_core.models import Event

    oracle = Oracle()
    oracle.ingest("user1", [Event(...)])
    oracle.train("user1")
    predictions = oracle.anticipate("user1")
"""

__version__ = "0.1.0"

from .engine import Oracle
from .models import Event, Prediction, Feedback, FeedbackOutcome, PredictionCategory
from .recommend import RecommendableItem

__all__ = [
    "Oracle",
    "Event",
    "Prediction",
    "Feedback",
    "FeedbackOutcome",
    "PredictionCategory",
    "RecommendableItem",
]
