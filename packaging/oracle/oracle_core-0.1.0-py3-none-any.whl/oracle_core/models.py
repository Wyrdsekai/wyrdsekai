"""Core data models for oracle-core.

Events are the universal input. Predictions are the universal output.
Everything in between is the Oracle's job.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


# ── Input: Events ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Event:
    """A single thing that happened. Universal input format.

    Events can come from anywhere: app activity, email, RSS, system metrics,
    health sensors, calendar, search queries, code commits. The Oracle doesn't
    care about the source — it cares about the timestamp, type, and content.
    """

    timestamp: datetime
    source: str  # "room_event", "email", "rss", "system", "health", "calendar", ...
    event_type: str  # "said", "search", "commit", "heartbeat", "article", ...
    content: str = ""  # text payload (title, message, query — whatever is relevant)
    metadata: dict[str, Any] = field(default_factory=dict)  # source-specific fields

    # Optional structured fields (extracted during ingestion)
    entity_id: str = ""  # who caused it (user, agent, system)
    room_id: str = ""  # where it happened (MUD room, or app context)
    numeric_value: float | None = None  # for time series (CPU %, steps, temperature)
    tags: list[str] = field(default_factory=list)  # extracted topics/categories


# ── Output: Predictions ──────────────────────────────────────────────────────


class PredictionCategory(str, Enum):
    """What kind of prediction this is."""

    PATTERN = "pattern"  # recurring temporal pattern detected
    ANOMALY = "anomaly"  # something unusual happened or is happening
    FORECAST = "forecast"  # time series prediction with confidence interval
    CORRELATION = "correlation"  # two signals are connected
    TOPIC = "topic"  # topic emergence, shift, or decline
    SEQUENCE = "sequence"  # behavioral sequence prediction
    RECOMMENDATION = "recommendation"  # content/action suggestion
    ANTICIPATION = "anticipation"  # synthesized insight combining multiple signals


@dataclass
class Prediction:
    """A single prediction or insight from the Oracle.

    This is what gets surfaced to the user — either as room narration,
    spawned objects, notifications, or agent context.
    """

    id: str
    text: str  # human-readable description (resolved from text_key + text_params)
    category: PredictionCategory
    confidence: float  # 0.0 to 1.0
    text_key: str = ""  # i18n key (e.g. "oracle.pattern.periodic") — consumers re-translate
    text_params: dict[str, str] = field(default_factory=dict)  # params for i18n template
    evidence: str = ""  # what data supports this prediction
    source_events: list[str] = field(default_factory=list)  # event IDs that contributed
    actionable: bool = False  # does this suggest a specific action?

    # For forecasts: the actual numbers
    forecast_values: list[ForecastPoint] | None = None

    # For manifestation in Wyrdsekai rooms (optional — ignored by non-MUD consumers)
    manifestation: Manifestation | None = None

    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at: datetime | None = None  # auto-expire stale predictions


@dataclass(frozen=True)
class ForecastPoint:
    """A single point in a time series forecast."""

    timestamp: datetime
    predicted: float
    lower_bound: float  # confidence interval lower
    upper_bound: float  # confidence interval upper


@dataclass
class Manifestation:
    """How a prediction should manifest in a Wyrdsekai room.

    Optional — oracle-core produces these, but non-MUD consumers ignore them.
    Wyrdsekai room scripts read these to change the environment.
    """

    room: str  # target room ("study", "bridge", "boiler-room")
    type: str  # "narration", "object_spawn", "description_change", "alert", "hint"
    narration: str | None = None
    object_spawn: dict[str, str] | None = None  # {id, name, description, on_use_text}
    description_change: str | None = None
    hint: dict[str, str] | None = None  # {label, action}


# ── Feedback ─────────────────────────────────────────────────────────────────


class FeedbackOutcome(str, Enum):
    CORRECT = "correct"
    WRONG = "wrong"
    PARTIAL = "partial"
    IGNORED = "ignored"  # prediction surfaced but user didn't engage


@dataclass
class Feedback:
    """Outcome of a prediction — did it turn out right?"""

    prediction_id: str
    outcome: FeedbackOutcome
    user_engaged: bool = False  # did the user interact with it?
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
