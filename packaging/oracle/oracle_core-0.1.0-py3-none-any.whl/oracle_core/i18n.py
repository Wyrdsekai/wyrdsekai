"""Internationalization for oracle-core predictions.

All user-facing text goes through t() which resolves a key + params
to a localized string. Ships with English defaults. Consumers can
load their own locale JSON to override.

Usage:
    from oracle_core.i18n import t, load_locale

    # Default: English
    t("oracle.pattern.weekly_cycle", label="activity", r="0.85")

    # Load Japanese
    load_locale("ja", "/path/to/oracle_ja.json")
    t("oracle.pattern.weekly_cycle", label="アクティビティ", r="0.85")
"""

from __future__ import annotations

import json
from pathlib import Path

# Active translations: key → template string
_translations: dict[str, str] = {}
_locale: str = "en"


def t(key: str, **params: str | int | float) -> str:
    """Resolve an i18n key with parameters.

    Returns the localized string with {param} placeholders filled.
    Falls back to the key itself if not found.
    """
    template = _translations.get(key, key)
    if params:
        try:
            return template.format(**{k: str(v) for k, v in params.items()})
        except (KeyError, IndexError):
            return template
    return template


def load_locale(locale: str, path: str | None = None) -> None:
    """Load translations for a locale.

    If path is None, loads from the bundled oracle_core/i18n/ directory.
    """
    global _translations, _locale
    _locale = locale

    if path:
        _load_from_file(path)
    else:
        # Load bundled
        bundled = Path(__file__).parent / "i18n" / f"oracle_{locale}.json"
        if bundled.exists():
            _load_from_file(str(bundled))
        elif locale != "en":
            # Fall back to English
            en_path = Path(__file__).parent / "i18n" / "oracle_en.json"
            if en_path.exists():
                _load_from_file(str(en_path))


def get_locale() -> str:
    """Current active locale."""
    return _locale


def _load_from_file(path: str) -> None:
    global _translations
    try:
        with open(path, encoding="utf-8") as f:
            _translations = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        pass  # keep existing translations


# Auto-load English on import
def _init():
    bundled = Path(__file__).parent / "i18n" / "oracle_en.json"
    if bundled.exists():
        _load_from_file(str(bundled))

_init()
