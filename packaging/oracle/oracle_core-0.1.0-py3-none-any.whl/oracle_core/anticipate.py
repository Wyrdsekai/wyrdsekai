"""Anticipation engine — synthesizes all analysis modules into ranked insights.

This is the Oracle's highest-level output. It combines patterns, anomalies,
forecasts, topics, correlations, and sequences into a unified set of
actionable predictions, ranked by confidence and relevance.

Also handles manifestation — how predictions should appear in a MUD room.
"""

from __future__ import annotations

import uuid

from .i18n import t
from .models import (
    Event,
    Manifestation,
    Prediction,
    PredictionCategory,
)


class Anticipator:
    """Synthesizes predictions from all modules into ranked insights."""

    def __init__(self, min_confidence: float = 0.65, max_predictions: int = 20):
        self.min_confidence = min_confidence
        self.max_predictions = max_predictions

    def synthesize(
        self,
        predictions: list[Prediction],
        events: list[Event] | None = None,
    ) -> list[Prediction]:
        """Take raw predictions from all modules, deduplicate, rank, and cap.

        Also generates compound insights by combining related predictions.
        """
        if not predictions:
            return []

        # 1. Filter by confidence threshold
        filtered = [p for p in predictions if p.confidence >= self.min_confidence]

        # 2. Deduplicate similar predictions
        deduped = self._deduplicate(filtered)

        # 3. Generate compound insights from related predictions
        compounds = self._find_compounds(deduped, events)
        deduped.extend(compounds)

        # 4. Sort by confidence (highest first), then by category priority
        category_priority = {
            PredictionCategory.ANTICIPATION: 0,
            PredictionCategory.ANOMALY: 1,
            PredictionCategory.RECOMMENDATION: 2,
            PredictionCategory.CORRELATION: 3,
            PredictionCategory.FORECAST: 4,
            PredictionCategory.TOPIC: 5,
            PredictionCategory.SEQUENCE: 6,
            PredictionCategory.PATTERN: 7,
        }

        deduped.sort(key=lambda p: (category_priority.get(p.category, 99), -p.confidence))

        # 5. Cap at max
        return deduped[: self.max_predictions]

    def add_manifestations(
        self,
        predictions: list[Prediction],
        available_rooms: list[str] | None = None,
    ) -> list[Prediction]:
        """Add room manifestation data to predictions.

        Maps prediction categories to room objects, narration, and hints.
        Only relevant for Wyrdsekai — non-MUD consumers ignore manifestation.
        """
        rooms = available_rooms or ["study"]

        for pred in predictions:
            pred.manifestation = self._manifest(pred, rooms)

        return predictions

    def _deduplicate(self, predictions: list[Prediction]) -> list[Prediction]:
        """Remove near-duplicate predictions (same category + similar text)."""
        seen_keys: set[str] = set()
        result = []

        for p in predictions:
            # Key: category + first 40 chars of text stripped of parentheticals
            clean_text = p.text.split("(")[0].strip().lower()[:40]
            key = f"{p.category.value}:{clean_text}"
            if key not in seen_keys:
                seen_keys.add(key)
                result.append(p)

        return result

    def _find_compounds(
        self,
        predictions: list[Prediction],
        events: list[Event] | None,
    ) -> list[Prediction]:
        """Find related predictions and create compound insights.

        E.g., topic shift + anomaly + forecast all pointing to the same thing
        → "Multiple signals suggest X is changing."
        """
        compounds = []

        # Group by keywords in text
        keyword_groups: dict[str, list[Prediction]] = {}
        for p in predictions:
            words = set(p.text.lower().split())
            # Extract meaningful words (skip common ones)
            skip = {"the", "a", "is", "are", "your", "has", "been", "for", "and", "over", "in", "of", "to"}
            meaningful = words - skip
            for word in meaningful:
                if len(word) > 4:  # only meaningful words
                    keyword_groups.setdefault(word, []).append(p)

        # Find groups with 3+ predictions sharing a keyword → compound
        for keyword, group in keyword_groups.items():
            if len(group) >= 3:
                # Multiple signals point to same topic
                categories = set(p.category.value for p in group)
                if len(categories) >= 2:  # from different analysis modules
                    avg_confidence = sum(p.confidence for p in group) / len(group)
                    compound_confidence = min(avg_confidence + 0.1, 0.95)

                    source_ids = []
                    for p in group:
                        source_ids.append(p.id)

                    cp = {
                        "keyword": keyword,
                        "count": str(len(group)),
                        "categories": ", ".join(sorted(categories)),
                    }
                    compounds.append(Prediction(
                        id=f"compound-{uuid.uuid4().hex[:8]}",
                        text=t("oracle.compound.converging", **cp),
                        text_key="oracle.compound.converging",
                        text_params=cp,
                        category=PredictionCategory.ANTICIPATION,
                        confidence=compound_confidence,
                        evidence=f"Compound from {len(group)} predictions across {len(categories)} categories",
                        source_events=source_ids,
                        actionable=True,
                    ))

        return compounds

    def _manifest(self, pred: Prediction, rooms: list[str]) -> Manifestation:
        """Map a prediction to a room manifestation."""
        # Pick the target room based on prediction category
        room = self._pick_room(pred, rooms)

        if pred.category == PredictionCategory.ANOMALY:
            return Manifestation(
                room=room,
                type="alert",
                narration=pred.text,
                object_spawn={
                    "id": f"alert-{pred.id}",
                    "name": t("oracle.manifest.crystal_name"),
                    "description": t("oracle.manifest.crystal_desc"),
                    "on_use_text": pred.text,
                },
                hint={"label": "Why is the crystal glowing?", "action": f"say:explain {pred.id}"},
            )
        elif pred.category == PredictionCategory.FORECAST:
            return Manifestation(
                room=room,
                type="object_spawn",
                narration=None,
                object_spawn={
                    "id": f"scroll-{pred.id}",
                    "name": t("oracle.manifest.scroll_name"),
                    "description": t("oracle.manifest.scroll_desc"),
                    "on_use_text": pred.text,
                },
                hint={"label": "Check the forecast", "action": "say:forecast"},
            )
        elif pred.category == PredictionCategory.RECOMMENDATION:
            return Manifestation(
                room=room,
                type="object_spawn",
                object_spawn={
                    "id": f"book-{pred.id}",
                    "name": t("oracle.manifest.book_name"),
                    "description": t("oracle.manifest.book_desc"),
                    "on_use_text": pred.text,
                },
                hint={"label": "New book on shelf", "action": "use:glowing book"},
            )
        elif pred.category == PredictionCategory.TOPIC:
            return Manifestation(
                room=room,
                type="narration",
                narration=pred.text,
                hint={"label": "Topic trends", "action": "say:topics"},
            )
        elif pred.category == PredictionCategory.CORRELATION:
            return Manifestation(
                room=room,
                type="narration",
                narration=pred.text,
                description_change=t("oracle.manifest.pattern_board"),
            )
        elif pred.category == PredictionCategory.ANTICIPATION:
            return Manifestation(
                room=room,
                type="object_spawn",
                narration=pred.text,
                object_spawn={
                    "id": f"letter-{pred.id}",
                    "name": t("oracle.manifest.letter_name"),
                    "description": t("oracle.manifest.letter_desc"),
                    "on_use_text": pred.text,
                },
                hint={"label": "Read the letter", "action": "use:sealed letter"},
            )
        else:
            return Manifestation(
                room=room,
                type="narration",
                narration=pred.text,
            )

    def _pick_room(self, pred: Prediction, rooms: list[str]) -> str:
        """Pick the best room for a prediction based on its category."""
        room_affinity = {
            PredictionCategory.PATTERN: "study",
            PredictionCategory.ANOMALY: "bridge",
            PredictionCategory.FORECAST: "study",
            PredictionCategory.CORRELATION: "study",
            PredictionCategory.TOPIC: "study",
            PredictionCategory.SEQUENCE: "study",
            PredictionCategory.RECOMMENDATION: "study",
            PredictionCategory.ANTICIPATION: "study",
        }
        preferred = room_affinity.get(pred.category, "study")
        return preferred if preferred in rooms else rooms[0]
