"""Temporal pattern detection.

Finds recurring patterns in event streams: daily rhythms, weekly cycles,
behavioral clusters. Uses autocorrelation for periodicity and KMeans for
activity type clustering.
"""

from __future__ import annotations

import uuid
from datetime import datetime

import numpy as np
from scipy.signal import find_peaks
from sklearn.cluster import KMeans

from .i18n import t
from .models import Event, Prediction, PredictionCategory


class PatternDetector:
    """Detects recurring temporal patterns in event streams."""

    # Minimum data points before we attempt detection
    MIN_DAILY_POINTS = 14  # 2 weeks
    MIN_HOURLY_POINTS = 72  # 3 days

    def detect(
        self,
        timestamps: list[datetime],
        values: list[float],
        source_label: str = "activity",
        window_hours: int = 24,
    ) -> list[Prediction]:
        """Detect patterns in a time series.

        Args:
            timestamps: Ordered timestamps
            values: Corresponding values (event counts, metrics, etc.)
            source_label: Human-readable label for the series
            window_hours: Window size used to produce the series

        Returns:
            List of detected patterns as Predictions.
        """
        if len(values) < self.MIN_DAILY_POINTS:
            return []

        predictions = []

        # 1. Periodicity detection via autocorrelation
        predictions.extend(
            self._detect_periodicity(timestamps, values, source_label, window_hours)
        )

        # 2. Trend detection (linear regression on recent window)
        predictions.extend(self._detect_trend(timestamps, values, source_label))

        return predictions

    def detect_clusters(
        self,
        events: list[Event],
        n_clusters: int = 3,
        min_events: int = 50,
    ) -> list[Prediction]:
        """Cluster events by time-of-day + day-of-week to find activity types.

        E.g., "morning admin", "afternoon creative", "evening reflection".
        """
        if len(events) < min_events:
            return []

        # Feature: [hour, day_of_week, content_length_normalized]
        features = []
        for e in events:
            hour = e.timestamp.hour + e.timestamp.minute / 60.0
            dow = e.timestamp.weekday()
            content_len = min(len(e.content) / 500.0, 1.0) if e.content else 0.0
            features.append([hour / 24.0, dow / 7.0, content_len])

        X = np.array(features)

        # Auto-select n_clusters via elbow heuristic (simple: try 2-5, pick best silhouette)
        from sklearn.metrics import silhouette_score

        best_k, best_score = n_clusters, -1
        for k in range(2, min(6, len(events) // 10 + 1)):
            km = KMeans(n_clusters=k, n_init=10, random_state=42)
            labels = km.fit_predict(X)
            score = silhouette_score(X, labels)
            if score > best_score:
                best_k, best_score = k, score

        km = KMeans(n_clusters=best_k, n_init=10, random_state=42)
        labels = km.fit_predict(X)

        predictions = []
        for i in range(best_k):
            cluster_events = [e for e, label in zip(events, labels) if label == i]
            if not cluster_events:
                continue

            hours = [e.timestamp.hour for e in cluster_events]
            avg_hour = np.mean(hours)
            days = [e.timestamp.weekday() for e in cluster_events]

            time_label = _hour_label(float(avg_hour))
            day_label = _day_label(days)
            count = len(cluster_events)
            pct = count / len(events) * 100

            cp = {
                "description": f"{time_label} {day_label}".strip(),
                "pct": f"{pct:.0f}",
                "count": str(count),
            }
            predictions.append(Prediction(
                id=f"pattern-cluster-{uuid.uuid4().hex[:8]}",
                text=t("oracle.pattern.cluster", **cp),
                text_key="oracle.pattern.cluster",
                text_params=cp,
                category=PredictionCategory.PATTERN,
                confidence=min(0.5 + best_score * 0.5, 0.95),  # silhouette → confidence
                evidence=f"KMeans k={best_k}, silhouette={best_score:.2f}",
            ))

        return predictions

    def _detect_periodicity(
        self,
        timestamps: list[datetime],
        values: list[float],
        label: str,
        window_hours: int,
    ) -> list[Prediction]:
        """Detect periodic patterns via autocorrelation."""
        arr = np.array(values, dtype=float)
        if arr.std() == 0:
            return []

        # Normalize
        arr = (arr - arr.mean()) / arr.std()

        # Autocorrelation
        n = len(arr)
        acf = np.correlate(arr, arr, mode="full")[n - 1:]
        acf = acf / acf[0]  # normalize

        # Find peaks in autocorrelation (skip lag 0)
        min_lag = 2
        max_lag = min(n // 2, 60)  # don't look beyond half the data or 60 windows
        if max_lag <= min_lag:
            return []

        peaks, properties = find_peaks(
            acf[min_lag:max_lag],
            height=0.3,  # minimum correlation
            distance=2,  # minimum distance between peaks
        )

        predictions = []
        for peak_idx, height in zip(peaks, properties["peak_heights"]):
            lag = peak_idx + min_lag
            period_hours = lag * window_hours

            period_label = _period_label(period_hours)
            confidence = min(float(height) * 0.8 + 0.2, 0.95)

            tp = {"label": label, "period": period_label, "r": f"{height:.2f}"}
            predictions.append(Prediction(
                id=f"pattern-period-{uuid.uuid4().hex[:8]}",
                text=t("oracle.pattern.periodic", **tp),
                text_key="oracle.pattern.periodic",
                text_params=tp,
                category=PredictionCategory.PATTERN,
                confidence=confidence,
                evidence=f"Autocorrelation peak at lag {lag} ({period_hours}h), r={height:.2f}, n={n}",
            ))

        return predictions

    def _detect_trend(
        self,
        timestamps: list[datetime],
        values: list[float],
        label: str,
        window: int = 14,
    ) -> list[Prediction]:
        """Detect linear trend in recent data."""
        if len(values) < window:
            return []

        recent = np.array(values[-window:], dtype=float)
        x = np.arange(len(recent), dtype=float)

        # Linear regression
        slope, intercept = np.polyfit(x, recent, 1)
        residuals = recent - (slope * x + intercept)
        r_squared = 1.0 - (np.var(residuals) / np.var(recent)) if np.var(recent) > 0 else 0.0

        if abs(r_squared) < 0.3:
            return []  # weak trend

        confidence = min(abs(r_squared) * 0.7 + 0.3, 0.90)

        key = (
            "oracle.pattern.trend_increasing" if slope > 0
            else "oracle.pattern.trend_declining"
        )
        tp = {"label": label, "r2": f"{r_squared:.2f}", "window": str(window)}
        return [Prediction(
            id=f"pattern-trend-{uuid.uuid4().hex[:8]}",
            text=t(key, **tp),
            text_key=key,
            text_params=tp,
            category=PredictionCategory.PATTERN,
            confidence=confidence,
            evidence=f"Linear fit: slope={slope:.3f}/period, R²={r_squared:.2f}, window={window}",
        )]


def _hour_label(h: float) -> str:
    if 5 <= h < 9:
        return "early morning"
    if 9 <= h < 12:
        return "morning"
    if 12 <= h < 14:
        return "midday"
    if 14 <= h < 17:
        return "afternoon"
    if 17 <= h < 21:
        return "evening"
    return "night"


def _day_label(days: list[int]) -> str:
    weekend = sum(1 for d in days if d >= 5) / len(days) if days else 0
    if weekend > 0.7:
        return "weekends"
    if weekend < 0.3:
        return "weekdays"
    return ""


def _period_label(hours: int) -> str:
    if hours < 24:
        return f"{hours}-hour"
    days = hours // 24
    if days == 1:
        return "daily"
    if days == 7:
        return "weekly"
    if 28 <= days <= 31:
        return "monthly"
    return f"{days}-day"
