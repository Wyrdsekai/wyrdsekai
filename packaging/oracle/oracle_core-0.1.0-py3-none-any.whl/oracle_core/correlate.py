"""Cross-source correlation discovery.

Finds non-obvious connections between different event streams.
"When X happens, Y follows N days later." Uses cross-correlation
with lag analysis and Granger causality for directional inference.
"""

from __future__ import annotations

import uuid
from datetime import datetime

import numpy as np
from scipy.stats import pearsonr

from .i18n import t
from .models import Prediction, PredictionCategory


class CorrelationEngine:
    """Discovers correlations between pairs of time series."""

    def __init__(self, min_correlation: float = 0.3, max_lag: int = 7):
        """
        Args:
            min_correlation: Minimum absolute correlation to report.
            max_lag: Maximum lag (in periods) to check.
        """
        self.min_correlation = min_correlation
        self.max_lag = max_lag

    def correlate(
        self,
        timestamps: list[datetime],
        values_a: list[float],
        values_b: list[float],
        label_a: str = "series A",
        label_b: str = "series B",
    ) -> list[Prediction]:
        """Find correlation between two time series, including lagged correlations.

        Both series must share the same timestamps (aligned).
        """
        if len(values_a) < 20 or len(values_b) < 20:
            return []
        if len(values_a) != len(values_b):
            # Truncate to shorter
            n = min(len(values_a), len(values_b))
            values_a = values_a[:n]
            values_b = values_b[:n]
            timestamps = timestamps[:n]

        a = np.array(values_a, dtype=float)
        b = np.array(values_b, dtype=float)

        # Normalize
        if a.std() == 0 or b.std() == 0:
            return []
        a_norm = (a - a.mean()) / a.std()
        b_norm = (b - b.mean()) / b.std()

        predictions = []

        # 1. Zero-lag correlation
        r, p_value = pearsonr(a, b)
        if abs(r) >= self.min_correlation and p_value < 0.05:
            predictions.append(self._make_prediction(
                label_a, label_b, r, 0, p_value, len(a)
            ))

        # 2. Lagged cross-correlation
        best_lag, best_r, best_p = self._find_best_lag(a_norm, b_norm)
        if best_lag != 0 and abs(best_r) >= self.min_correlation:
            predictions.append(self._make_prediction(
                label_a, label_b, best_r, best_lag, best_p, len(a)
            ))

        return predictions

    def correlate_all_pairs(
        self,
        timestamps: list[datetime],
        series_dict: dict[str, list[float]],
    ) -> list[Prediction]:
        """Find correlations between all pairs of named time series."""
        names = list(series_dict.keys())
        predictions = []

        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                preds = self.correlate(
                    timestamps,
                    series_dict[names[i]],
                    series_dict[names[j]],
                    names[i],
                    names[j],
                )
                predictions.extend(preds)

        # Sort by absolute correlation strength
        predictions.sort(key=lambda p: -p.confidence)
        return predictions

    def _find_best_lag(
        self, a: np.ndarray, b: np.ndarray
    ) -> tuple[int, float, float]:
        """Find the lag with the strongest correlation."""
        n = len(a)
        best_lag = 0
        best_r = 0.0
        best_p = 1.0

        for lag in range(-self.max_lag, self.max_lag + 1):
            if lag == 0:
                continue

            if lag > 0:
                # a leads b by `lag` periods
                a_slice = a[:-lag] if lag < n else a[:1]
                b_slice = b[lag:] if lag < n else b[-1:]
            else:
                # b leads a by `|lag|` periods
                a_slice = a[-lag:]
                b_slice = b[:lag] if lag < 0 else b

            if len(a_slice) < 10 or len(b_slice) < 10:
                continue
            if len(a_slice) != len(b_slice):
                min_len = min(len(a_slice), len(b_slice))
                a_slice = a_slice[:min_len]
                b_slice = b_slice[:min_len]

            try:
                r, p = pearsonr(a_slice, b_slice)
                if abs(r) > abs(best_r) and p < 0.05:
                    best_lag = lag
                    best_r = r
                    best_p = p
            except ValueError:
                continue

        return best_lag, best_r, best_p

    def _make_prediction(
        self,
        label_a: str,
        label_b: str,
        r: float,
        lag: int,
        p_value: float,
        n: int,
    ) -> Prediction:
        """Create a Prediction from a correlation finding."""
        direction = t("oracle.correlation.positively") if r > 0 else t("oracle.correlation.negatively")
        if abs(r) > 0.6:
            strength = t("oracle.correlation.strongly")
        elif abs(r) > 0.4:
            strength = t("oracle.correlation.moderately")
        else:
            strength = ""

        cp = {
            "label_a": label_a,
            "label_b": label_b,
            "strength": strength,
            "direction": direction,
            "r": f"{r:.2f}",
            "lag": str(abs(lag)),
        }

        if lag == 0:
            key = "oracle.correlation.zero_lag"
        elif lag > 0:
            key = "oracle.correlation.a_leads"
        else:
            key = "oracle.correlation.b_leads"

        confidence = min(abs(r) * 0.7 + (1.0 - p_value) * 0.3, 0.95)

        return Prediction(
            id=f"corr-{uuid.uuid4().hex[:8]}",
            text=t(key, **cp),
            text_key=key,
            text_params=cp,
            category=PredictionCategory.CORRELATION,
            confidence=confidence,
            evidence=f"Pearson r={r:.3f}, p={p_value:.4f}, lag={lag}, n={n}",
        )
