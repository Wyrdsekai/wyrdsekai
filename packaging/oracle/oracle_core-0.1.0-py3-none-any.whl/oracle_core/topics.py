"""Topic evolution tracking.

Tracks what topics are emerging, growing, declining, or stable
across all text-bearing events. Uses TF-IDF + NMF decomposition.
No neural network required — works on any text data.
"""

from __future__ import annotations

import uuid
from collections import defaultdict
from datetime import timedelta

import numpy as np
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer

from .i18n import t
from .models import Event, Prediction, PredictionCategory


class TopicTracker:
    """Tracks topic evolution over time windows."""

    def __init__(self, n_topics: int = 8, min_events: int = 30):
        self.n_topics = n_topics
        self.min_events = min_events

    def analyze(
        self,
        events: list[Event],
        window_days: int = 7,
    ) -> list[Prediction]:
        """Analyze topic evolution over sliding time windows.

        Splits events into weekly windows, runs NMF on each,
        and tracks how topic weights change over time.
        """
        # Filter to events with text content
        text_events = [e for e in events if e.content and len(e.content) > 10]
        if len(text_events) < self.min_events:
            return []

        sorted_events = sorted(text_events, key=lambda e: e.timestamp)

        # Split into time windows
        windows = self._split_windows(sorted_events, window_days)
        if len(windows) < 2:
            return []

        # Build global vocabulary from all events
        all_texts = [e.content for e in sorted_events]
        vectorizer = TfidfVectorizer(
            max_features=500,
            stop_words="english",
            min_df=2,
            max_df=0.8,
        )

        try:
            tfidf_matrix = vectorizer.fit_transform(all_texts)
        except ValueError:
            return []  # too few terms

        feature_names = vectorizer.get_feature_names_out()

        # NMF decomposition
        n_topics = min(self.n_topics, tfidf_matrix.shape[1], len(all_texts) // 3)
        if n_topics < 2:
            return []

        nmf = NMF(n_components=n_topics, random_state=42, max_iter=300)
        try:
            doc_topics = nmf.fit_transform(tfidf_matrix)  # (n_docs, n_topics)
        except Exception:
            return []

        # Get top words per topic
        topic_labels = []
        for topic_idx in range(n_topics):
            top_word_indices = nmf.components_[topic_idx].argsort()[-5:][::-1]
            top_words = [feature_names[i] for i in top_word_indices]
            topic_labels.append(", ".join(top_words[:3]))

        # Track topic weights per window
        event_to_idx = {id(e): i for i, e in enumerate(sorted_events)}
        topic_trajectories: dict[int, list[float]] = defaultdict(list)

        for window_events in windows:
            window_weights = np.zeros(n_topics)
            count = 0
            for e in window_events:
                idx = event_to_idx.get(id(e))
                if idx is not None:
                    window_weights += doc_topics[idx]
                    count += 1
            if count > 0:
                window_weights /= count
            for ti in range(n_topics):
                topic_trajectories[ti].append(float(window_weights[ti]))

        # Detect interesting changes
        predictions = []
        for topic_idx in range(n_topics):
            trajectory = topic_trajectories[topic_idx]
            if len(trajectory) < 2:
                continue

            label = topic_labels[topic_idx]
            predictions.extend(
                self._analyze_trajectory(trajectory, label, topic_idx, window_days)
            )

        return predictions

    def _analyze_trajectory(
        self,
        trajectory: list[float],
        label: str,
        topic_idx: int,
        window_days: int,
    ) -> list[Prediction]:
        """Analyze a single topic's trajectory for interesting changes."""
        arr = np.array(trajectory)
        predictions = []

        if len(arr) < 2 or arr.max() < 0.01:
            return []

        # Emergence: topic was near zero, now significant
        first_half = arr[: len(arr) // 2]
        second_half = arr[len(arr) // 2:]

        if first_half.mean() < 0.02 and second_half.mean() > 0.05:
            growth = second_half.mean() / max(first_half.mean(), 0.001)
            confidence = min(0.5 + min(growth / 10, 0.4), 0.90)
            ep = {"keyword": label}
            predictions.append(Prediction(
                id=f"topic-emerge-{uuid.uuid4().hex[:8]}",
                text=t("oracle.topic.emerging", **ep),
                text_key="oracle.topic.emerging",
                text_params=ep,
                category=PredictionCategory.TOPIC,
                confidence=confidence,
                evidence=f"First half avg={first_half.mean():.3f}, second half avg={second_half.mean():.3f}",
            ))

        # Growth: steady increase
        elif len(arr) >= 3:
            slope = np.polyfit(np.arange(len(arr)), arr, 1)[0]
            if slope > 0.01:
                confidence = min(0.5 + slope * 10, 0.85)
                gp = {"keyword": label, "windows": str(len(arr))}
                predictions.append(Prediction(
                    id=f"topic-growth-{uuid.uuid4().hex[:8]}",
                    text=t("oracle.topic.growing", **gp),
                    text_key="oracle.topic.growing",
                    text_params=gp,
                    category=PredictionCategory.TOPIC,
                    confidence=confidence,
                    evidence=f"Slope={slope:.4f}/window, current weight={arr[-1]:.3f}",
                ))
            elif slope < -0.01:
                confidence = min(0.5 + abs(slope) * 10, 0.85)
                dp = {"keyword": label, "windows": str(len(arr))}
                predictions.append(Prediction(
                    id=f"topic-decline-{uuid.uuid4().hex[:8]}",
                    text=t("oracle.topic.declining", **dp),
                    text_key="oracle.topic.declining",
                    text_params=dp,
                    category=PredictionCategory.TOPIC,
                    confidence=confidence,
                    evidence=f"Slope={slope:.4f}/window, current weight={arr[-1]:.3f}",
                ))

        return predictions

    def _split_windows(
        self, events: list[Event], window_days: int
    ) -> list[list[Event]]:
        """Split sorted events into time windows."""
        if not events:
            return []

        windows = []
        start = events[0].timestamp
        end = events[-1].timestamp
        current = start
        delta = timedelta(days=window_days)

        while current < end:
            window_end = current + delta
            window = [e for e in events if current <= e.timestamp < window_end]
            if window:
                windows.append(window)
            current = window_end

        return windows
