"""The Oracle engine — ties all analysis modules together.

This is the main entry point for using oracle-core as a library.
Ingest events, run analysis, get predictions.

    from oracle_core import Oracle

    oracle = Oracle()
    oracle.ingest(events)
    oracle.train("user1")
    predictions = oracle.anticipate("user1")
"""

from __future__ import annotations

from typing import Any
from datetime import datetime, timedelta, timezone

from .anomaly import AnomalyDetector
from .anticipate import Anticipator
from .correlate import CorrelationEngine
from .feedback import FeedbackCalibrator
from .forecast import get_best_forecaster
from .ingest import FeaturePipeline
from .models import Event, Prediction, Feedback
from .patterns import PatternDetector
from .recommend import RecommendableItem, RecommendationEngine
from .sequences import SequencePredictor
from .store import OracleStore
from .topics import TopicTracker


class Oracle:
    """Main oracle-core engine.

    Usage:
        oracle = Oracle(data_dir="~/.oracle-core")
        oracle.ingest(user_id, events)
        oracle.train(user_id)
        predictions = oracle.anticipate(user_id)
    """

    def __init__(self, data_dir: str = "~/.oracle-core"):
        self.store = OracleStore(data_dir)
        self.pipeline = FeaturePipeline()
        self.pattern_detector = PatternDetector()
        self.anomaly_detector = AnomalyDetector()
        self.forecaster = get_best_forecaster()
        self.topic_tracker = TopicTracker()
        self.correlation_engine = CorrelationEngine()
        self.sequence_predictor = SequencePredictor()
        self.anticipator = Anticipator()
        self.calibrator = FeedbackCalibrator()
        self.recommender = RecommendationEngine()

    def ingest(self, user_id: str, events: list[Event]) -> int:
        """Ingest events into the store. Returns count ingested."""
        return self.store.append_events(user_id, events)

    def train(self, user_id: str, window_days: int = 90) -> dict:
        """Run training cycle — pattern detection + anomaly baseline.

        Call this during Forge sleep or periodically.
        Returns a summary of what was trained.
        """
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)

        if not events:
            return {"status": "no_data", "events": 0}

        summary: dict[str, Any] = {
            "status": "ok",
            "events": len(events),
            "models_updated": [],
        }

        # Extract daily time series
        timestamps, counts = self.pipeline.extract_time_series(events, metric="count")
        if timestamps:
            # Train pattern detector (stateless — just runs detection)
            patterns = self.pattern_detector.detect(timestamps, counts, "daily activity")
            if patterns:
                self.store.save_predictions(user_id, patterns)
                summary["models_updated"].append("patterns")
                summary["patterns_found"] = len(patterns)

            # Train anomaly detector baseline
            anomalies = self.anomaly_detector.detect_time_series(timestamps, counts, "daily activity")
            if anomalies:
                self.store.save_predictions(user_id, anomalies)
                summary["models_updated"].append("anomaly")
                summary["anomalies_found"] = len(anomalies)

        # Activity clustering
        clusters = self.pattern_detector.detect_clusters(events)
        if clusters:
            self.store.save_predictions(user_id, clusters)
            summary["models_updated"].append("clusters")
            summary["clusters_found"] = len(clusters)

        # Forecasting
        if timestamps:
            forecasts = self.forecaster.forecast(timestamps, counts, 14, "daily activity")
            if forecasts:
                self.store.save_predictions(user_id, forecasts)
                summary["models_updated"].append("forecast")

        # Topic evolution
        topics = self.topic_tracker.analyze(events)
        if topics:
            self.store.save_predictions(user_id, topics)
            summary["models_updated"].append("topics")
            summary["topics_found"] = len(topics)

        # Behavioral sequences
        sequences = self.sequence_predictor.analyze(events)
        if sequences:
            self.store.save_predictions(user_id, sequences)
            summary["models_updated"].append("sequences")
            summary["sequences_found"] = len(sequences)

        return summary

    def analyze_patterns(
        self,
        user_id: str,
        sources: list[str] | None = None,
        window_days: int = 90,
    ) -> list[Prediction]:
        """Run pattern detection on stored events."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)

        if sources:
            events = [e for e in events if e.source in sources]

        if not events:
            return []

        timestamps, counts = self.pipeline.extract_time_series(events, metric="count")
        if not timestamps:
            return []

        predictions = self.pattern_detector.detect(timestamps, counts, "activity")
        predictions.extend(self.pattern_detector.detect_clusters(events))
        return predictions

    def analyze_anomalies(
        self,
        user_id: str,
        sources: list[str] | None = None,
        window_days: int = 30,
    ) -> list[Prediction]:
        """Run anomaly detection on stored events."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)

        if sources:
            events = [e for e in events if e.source in sources]

        if not events:
            return []

        timestamps, counts = self.pipeline.extract_time_series(events, metric="count")
        return self.anomaly_detector.detect_time_series(timestamps, counts, "activity")

    def analyze_forecast(
        self,
        user_id: str,
        metric: str = "count",
        horizon: int = 14,
        window_days: int = 90,
    ) -> list[Prediction]:
        """Forecast a time series into the future."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)
        if not events:
            return []

        timestamps, values = self.pipeline.extract_time_series(events, metric=metric)
        if not timestamps:
            return []

        return self.forecaster.forecast(timestamps, values, horizon, f"{metric} forecast")

    def analyze_topics(
        self,
        user_id: str,
        sources: list[str] | None = None,
        window_days: int = 90,
    ) -> list[Prediction]:
        """Track topic evolution over time."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)

        if sources:
            events = [e for e in events if e.source in sources]

        return self.topic_tracker.analyze(events)

    def analyze_correlations(
        self,
        user_id: str,
        source_pairs: list[tuple[str, str]] | None = None,
        window_days: int = 90,
    ) -> list[Prediction]:
        """Find correlations between event sources."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)
        if not events:
            return []

        # Build per-source time series
        sources = set(e.source for e in events)
        if len(sources) < 2:
            return []

        timestamps, _ = self.pipeline.extract_time_series(events, metric="count")
        if not timestamps:
            return []

        series_dict: dict[str, list[float]] = {}
        for src in sources:
            src_events = [e for e in events if e.source == src]
            _, vals = self.pipeline.extract_time_series(src_events, metric="count")
            # Align to global timestamps (pad with zeros)
            aligned = self._align_series(timestamps, src_events, window_hours=24)
            series_dict[src] = aligned

        if source_pairs:
            predictions = []
            for a, b in source_pairs:
                if a in series_dict and b in series_dict:
                    predictions.extend(
                        self.correlation_engine.correlate(
                            timestamps, series_dict[a], series_dict[b], a, b
                        )
                    )
            return predictions

        return self.correlation_engine.correlate_all_pairs(timestamps, series_dict)

    def analyze_sequences(
        self,
        user_id: str,
        window_days: int = 30,
    ) -> list[Prediction]:
        """Detect behavioral action sequences."""
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)
        if not events:
            return []

        return self.sequence_predictor.analyze(events)

    def _align_series(
        self,
        global_timestamps: list[datetime],
        events: list[Event],
        window_hours: int = 24,
    ) -> list[float]:
        """Align events to global timestamp grid (count per window)."""
        delta = timedelta(hours=window_hours)
        counts = []
        for ts in global_timestamps:
            count = sum(1 for e in events if ts <= e.timestamp < ts + delta)
            counts.append(float(count))
        return counts

    def anticipate(
        self,
        user_id: str,
        min_confidence: float = 0.65,
        rooms: list[str] | None = None,
    ) -> list[Prediction]:
        """Run all analysis and return ranked, calibrated, manifested predictions.

        This is the main output — what the user (or agent) sees.
        """
        raw: list[Prediction] = []

        # Patterns
        raw.extend(self.analyze_patterns(user_id))

        # Anomalies
        raw.extend(self.analyze_anomalies(user_id))

        # Forecasts
        raw.extend(self.analyze_forecast(user_id))

        # Topics
        raw.extend(self.analyze_topics(user_id))

        # Correlations (if multiple sources)
        raw.extend(self.analyze_correlations(user_id))

        # Sequences
        raw.extend(self.analyze_sequences(user_id))

        # Apply calibration (adjusts confidence based on historical accuracy)
        raw = self.calibrator.calibrate_predictions(raw)

        # Load events for compound insight synthesis
        events = self.store.load_events(user_id, limit=500)

        # Synthesize: deduplicate, find compounds, rank
        self.anticipator.min_confidence = min_confidence
        predictions = self.anticipator.synthesize(raw, events)

        # Add room manifestations if rooms specified
        if rooms:
            predictions = self.anticipator.add_manifestations(predictions, rooms)

        # Save for tracking
        if predictions:
            self.store.save_predictions(user_id, predictions)

        return predictions

    def recommend(
        self,
        user_id: str,
        items: list[RecommendableItem],
        consumed_ids: set[str] | None = None,
        window_days: int = 30,
    ) -> list[Prediction]:
        """Generate personalized recommendations from available items.

        Args:
            user_id: User to recommend for
            items: Available items (books, articles, podcasts, etc.)
            consumed_ids: Items already consumed (to exclude)
            window_days: How far back to look for user interests
        """
        since = datetime.now(timezone.utc) - timedelta(days=window_days)
        events = self.store.load_events(user_id, since=since)
        if not events:
            return []

        return self.recommender.recommend(events, items, consumed_ids)

    def feedback(self, user_id: str, fb: Feedback, category: str | None = None) -> None:
        """Record prediction outcome feedback and update calibration."""
        self.store.save_feedback(user_id, fb)
        if category:
            self.calibrator.record(category, fb)

    def calibration_summary(self) -> dict:
        """Return calibration stats — how accurate each prediction type is."""
        return self.calibrator.summary()

    def stats(self, user_id: str) -> dict:
        """Basic stats about stored data for a user."""
        return {
            "event_count": self.store.event_count(user_id),
            "recent_predictions": len(self.store.load_predictions(user_id, limit=20)),
        }
