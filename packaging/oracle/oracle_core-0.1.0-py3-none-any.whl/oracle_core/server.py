"""Flask API server for oracle-core.

Optional — oracle-core works as a library without the server.
The server enables integration with non-Python systems (e.g., Wyrdsekai's Java server).

Usage:
    oracle-server                    # starts on port 7073
    oracle-server --port 8080       # custom port
    oracle-server --data-dir /path  # custom data directory
"""

from __future__ import annotations

import argparse
import logging
import time
from datetime import datetime
from functools import wraps
from typing import Any, Callable

from flask import Flask, jsonify, request, g

from .engine import Oracle
from .models import Event, Feedback, FeedbackOutcome

app = Flask(__name__)
oracle: Oracle | None = None

# Structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [oracle] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger("oracle-core")

# Simple in-memory rate limiter
_rate_counts: dict[str, list[float]] = {}
RATE_LIMIT = 100  # requests per minute per IP
RATE_WINDOW = 60.0  # seconds


def rate_limited(f: Callable) -> Callable:
    """Simple rate limiting decorator."""
    @wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ip = request.remote_addr or "unknown"
        now = time.time()
        if ip not in _rate_counts:
            _rate_counts[ip] = []
        # Prune old entries
        _rate_counts[ip] = [t for t in _rate_counts[ip] if now - t < RATE_WINDOW]
        if len(_rate_counts[ip]) >= RATE_LIMIT:
            return jsonify({"error": "rate limit exceeded"}), 429
        _rate_counts[ip].append(now)
        return f(*args, **kwargs)
    return wrapper


@app.before_request
def log_request():
    g.start_time = time.time()


@app.after_request
def log_response(response):
    duration = (time.time() - g.get("start_time", time.time())) * 1000
    log.info("%s %s %d %.1fms", request.method, request.path, response.status_code, duration)
    return response


def get_oracle() -> Oracle:
    global oracle
    if oracle is None:
        oracle = Oracle()
    return oracle


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "version": "0.1.0",
    })


@app.route("/v1/ingest", methods=["POST"])
@rate_limited
def ingest():
    data = request.get_json()
    if not data:
        return jsonify({"error": "request body must be JSON"}), 400
    if "events" not in data:
        return jsonify({"error": "missing 'events' field"}), 400
    if not isinstance(data["events"], list):
        return jsonify({"error": "'events' must be an array"}), 400
    if len(data["events"]) > 10000:
        return jsonify({"error": "max 10000 events per request"}), 400

    user_id = data.get("user_id", "default")
    if not user_id or not isinstance(user_id, str) or len(user_id) > 100:
        return jsonify({"error": "invalid user_id"}), 400
    events = []
    for raw in data["events"]:
        try:
            events.append(Event(
                timestamp=datetime.fromisoformat(raw["timestamp"]),
                source=raw.get("source", ""),
                event_type=raw.get("event_type", ""),
                content=raw.get("content", ""),
                metadata=raw.get("metadata", {}),
                entity_id=raw.get("entity_id", ""),
                room_id=raw.get("room_id", ""),
                numeric_value=raw.get("numeric_value"),
                tags=raw.get("tags", []),
            ))
        except (KeyError, ValueError):
            continue  # skip malformed events

    count = get_oracle().ingest(user_id, events)
    return jsonify({"ingested": count})


@app.route("/v1/analyze/patterns", methods=["POST"])
@rate_limited
def analyze_patterns():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    sources = data.get("sources")
    window_days = data.get("window_days", 90)

    predictions = get_oracle().analyze_patterns(user_id, sources, window_days)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/anomalies", methods=["POST"])
@rate_limited
def analyze_anomalies():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    sources = data.get("sources")
    window_days = data.get("window_days", 30)

    predictions = get_oracle().analyze_anomalies(user_id, sources, window_days)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/forecast", methods=["POST"])
@rate_limited
def analyze_forecast():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    metric = data.get("metric", "count")
    horizon = data.get("horizon_days", 14)
    predictions = get_oracle().analyze_forecast(user_id, metric, horizon)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/topics", methods=["POST"])
@rate_limited
def analyze_topics():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    sources = data.get("sources")
    window_days = data.get("window_days", 90)
    predictions = get_oracle().analyze_topics(user_id, sources, window_days)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/correlations", methods=["POST"])
@rate_limited
def analyze_correlations():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    predictions = get_oracle().analyze_correlations(user_id)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/sequences", methods=["POST"])
@rate_limited
def analyze_sequences():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    predictions = get_oracle().analyze_sequences(user_id)
    return jsonify({"predictions": [_pred_dict(p) for p in predictions]})


@app.route("/v1/analyze/anticipate", methods=["POST"])
@rate_limited
def analyze_anticipate():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    min_confidence = data.get("min_confidence", 0.65)

    predictions = get_oracle().anticipate(user_id, min_confidence)
    return jsonify({"insights": [_pred_dict(p) for p in predictions]})


@app.route("/v1/train", methods=["POST"])
@rate_limited
def train():
    data = request.get_json() or {}
    user_id = data.get("user_id", "default")
    window_days = data.get("window_days", 90)

    result = get_oracle().train(user_id, window_days)
    return jsonify(result)


@app.route("/v1/feedback", methods=["POST"])
@rate_limited
def feedback():
    data = request.get_json()
    if not data or "prediction_id" not in data:
        return jsonify({"error": "missing 'prediction_id'"}), 400

    user_id = data.get("user_id", "default")
    fb = Feedback(
        prediction_id=data["prediction_id"],
        outcome=FeedbackOutcome(data.get("outcome", "ignored")),
        user_engaged=data.get("user_engaged", False),
    )
    get_oracle().feedback(user_id, fb)
    return jsonify({"status": "ok"})


@app.route("/v1/stats", methods=["GET"])
@rate_limited
def stats():
    user_id = request.args.get("user_id", "default")
    return jsonify(get_oracle().stats(user_id))


def _pred_dict(p) -> dict:
    return {
        "id": p.id,
        "text": p.text,
        "category": p.category.value,
        "confidence": round(p.confidence, 3),
        "evidence": p.evidence,
        "actionable": p.actionable,
        "created_at": p.created_at.isoformat(),
    }


def main():
    parser = argparse.ArgumentParser(description="oracle-core server")
    parser.add_argument("--port", type=int, default=7073)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--data-dir", default="~/.oracle-core")
    args = parser.parse_args()

    global oracle
    oracle = Oracle(data_dir=args.data_dir)

    print(f"oracle-core server starting on {args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
