"""Recommendation engine — trajectory-aware, cross-domain.

Not collaborative filtering ("people like you liked X").
This is personal trajectory matching ("based on where YOU are going, X is next").

Recommendations come from:
- Content similarity (TF-IDF or embeddings) between user interests and available items
- Temporal relevance (what's timely right now based on patterns)
- Gap detection (what's missing from the user's trajectory)
- Cross-domain bridging (book about X → podcast about X → project using X)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .i18n import t
from .models import Event, Prediction, PredictionCategory, Manifestation


@dataclass
class RecommendableItem:
    """Something that can be recommended — book, article, podcast, project, person."""

    id: str
    title: str
    description: str
    item_type: str  # "book", "article", "podcast", "movie", "project", "person", "paper"
    source: str  # "gutenberg", "arxiv", "hacker_news", "tmdb", "tastedive", "library"
    url: str = ""
    metadata: dict = field(default_factory=dict)  # source-specific: author, year, rating, etc.


class RecommendationEngine:
    """Generates personalized recommendations by matching user trajectory to available items."""

    def __init__(self, min_score: float = 0.05, max_recommendations: int = 10):
        self.min_score = min_score
        self.max_recommendations = max_recommendations

    def recommend(
        self,
        user_events: list[Event],
        available_items: list[RecommendableItem],
        consumed_ids: set[str] | None = None,
    ) -> list[Prediction]:
        """Generate recommendations from user activity + available items.

        Args:
            user_events: Recent user events (searches, journal, activity)
            available_items: Pool of recommendable items
            consumed_ids: Items the user has already consumed (to exclude)

        Returns:
            Ranked list of recommendation Predictions.
        """
        if not user_events or not available_items:
            return []

        consumed = consumed_ids or set()

        # Filter out already consumed
        candidates = [item for item in available_items if item.id not in consumed]
        if not candidates:
            return []

        # Build user interest profile from recent events
        user_texts = self._build_interest_profile(user_events)
        if not user_texts:
            return []

        # Build item descriptions
        item_texts = [f"{item.title} {item.description}" for item in candidates]

        # TF-IDF similarity
        try:
            all_texts = [user_texts] + item_texts
            vectorizer = TfidfVectorizer(max_features=1000, stop_words="english")
            tfidf_matrix = vectorizer.fit_transform(all_texts)

            # Similarity between user profile (row 0) and each item
            user_vector = tfidf_matrix[0:1]
            item_vectors = tfidf_matrix[1:]
            similarities = cosine_similarity(user_vector, item_vectors)[0]
        except ValueError:
            return []

        # Score and rank
        scored = []
        for i, (item, sim) in enumerate(zip(candidates, similarities)):
            if sim < self.min_score:
                continue

            # Boost by recency of matching interest
            recency_boost = self._recency_boost(user_events, item)
            final_score = float(sim) * 0.7 + recency_boost * 0.3

            scored.append((item, final_score, float(sim)))

        scored.sort(key=lambda x: -x[1])
        scored = scored[: self.max_recommendations]

        # Convert to Predictions
        predictions = []
        for item, score, sim in scored:
            confidence = min(score * 0.8 + 0.2, 0.90)
            why = self._explain_match(user_events, item)

            rp = {
                "item_type": item.item_type,
                "title": item.title,
                "reason": why,
            }
            predictions.append(Prediction(
                id=f"rec-{uuid.uuid4().hex[:8]}",
                text=t("oracle.recommend.item", **rp),
                text_key="oracle.recommend.item",
                text_params=rp,
                category=PredictionCategory.RECOMMENDATION,
                confidence=confidence,
                evidence=f"TF-IDF similarity={sim:.3f}, recency-adjusted score={score:.3f}",
                actionable=True,
                manifestation=Manifestation(
                    room="study",
                    type="object_spawn",
                    object_spawn={
                        "id": f"rec-obj-{item.id}",
                        "name": f"glowing {item.item_type}",
                        "description": f"A new {item.item_type} has appeared: \"{item.title}\"",
                        "on_use_text": f"{item.title}\n{item.description}\n\n{why}",
                    },
                    hint={
                        "label": f"New {item.item_type}: {item.title[:30]}",
                        "action": f"use:glowing {item.item_type}",
                    },
                ),
            ))

        return predictions

    def _build_interest_profile(self, events: list[Event]) -> str:
        """Build a text profile of user interests from recent events."""
        # Weight recent events more heavily (repeat them)
        texts = []
        for i, e in enumerate(sorted(events, key=lambda x: x.timestamp)):
            if not e.content or len(e.content) < 5:
                continue
            # More recent = more repetitions (up to 3x)
            weight = 1 + int(i / max(len(events) // 3, 1))
            for _ in range(min(weight, 3)):
                texts.append(e.content)

        return " ".join(texts[-200:])  # cap at 200 segments

    def _recency_boost(self, events: list[Event], item: RecommendableItem) -> float:
        """Boost score if the item matches very recent activity."""
        if not events:
            return 0.0

        recent = events[-10:]  # last 10 events
        item_words = set(item.title.lower().split() + item.description.lower().split())
        item_words -= {"the", "a", "an", "is", "of", "in", "to", "and", "for", "on", "with"}

        matches = 0
        for e in recent:
            event_words = set(e.content.lower().split())
            overlap = len(item_words & event_words)
            if overlap >= 2:
                matches += 1

        return min(matches / 5.0, 1.0)

    def _explain_match(self, events: list[Event], item: RecommendableItem) -> str:
        """Generate a human-readable explanation for why this item was recommended."""
        # Find the most relevant recent event
        item_words = set(item.title.lower().split() + item.description.lower().split())
        item_words -= {"the", "a", "an", "is", "of", "in", "to", "and", "for", "on", "with"}

        best_event = None
        best_overlap = 0

        for e in reversed(events):
            if not e.content:
                continue
            event_words = set(e.content.lower().split())
            overlap = len(item_words & event_words)
            if overlap > best_overlap:
                best_overlap = overlap
                best_event = e

        if best_event and best_overlap >= 2:
            return t("oracle.recommend.reason_match", context=best_event.content[:60])

        return t("oracle.recommend.reason_general")
