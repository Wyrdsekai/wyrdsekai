"""Behavioral sequence prediction.

Detects repeated action sequences and predicts what comes next.
"You search → read → write code. You just searched."

Uses n-gram models on action sequences. Simple, fast, interpretable.
"""

from __future__ import annotations

import uuid
from collections import Counter, defaultdict
from datetime import timedelta

from .i18n import t
from .models import Event, Prediction, PredictionCategory


class SequencePredictor:
    """Finds and predicts behavioral action sequences."""

    def __init__(self, max_gap_minutes: int = 60, min_frequency: int = 3):
        """
        Args:
            max_gap_minutes: Maximum gap between events to consider them in the same sequence.
            min_frequency: Minimum times a sequence must appear to be reported.
        """
        self.max_gap_minutes = max_gap_minutes
        self.min_frequency = min_frequency

    def analyze(
        self,
        events: list[Event],
        ngram_sizes: list[int] | None = None,
    ) -> list[Prediction]:
        """Find frequent action sequences and predict what's next.

        Args:
            events: Sorted events
            ngram_sizes: N-gram sizes to check (default: [2, 3, 4])
        """
        if ngram_sizes is None:
            ngram_sizes = [2, 3, 4]

        if len(events) < 20:
            return []

        # Build action sequences (split by time gaps)
        sessions = self._split_sessions(events)
        if not sessions:
            return []

        # Extract action labels from events
        action_sessions = []
        for session in sessions:
            actions = [self._event_to_action(e) for e in session]
            # Deduplicate consecutive identical actions
            deduped = [actions[0]]
            for a in actions[1:]:
                if a != deduped[-1]:
                    deduped.append(a)
            if len(deduped) >= 2:
                action_sessions.append(deduped)

        predictions = []

        for n in ngram_sizes:
            predictions.extend(self._find_ngrams(action_sessions, n))

        # Also: predict next action based on recent context
        if events:
            recent_actions = [self._event_to_action(e) for e in events[-5:]]
            predictions.extend(self._predict_next(action_sessions, recent_actions))

        return predictions

    def _split_sessions(self, events: list[Event]) -> list[list[Event]]:
        """Split events into sessions by time gaps."""
        if not events:
            return []

        sorted_events = sorted(events, key=lambda e: e.timestamp)
        sessions = [[sorted_events[0]]]
        max_gap = timedelta(minutes=self.max_gap_minutes)

        for e in sorted_events[1:]:
            if e.timestamp - sessions[-1][-1].timestamp > max_gap:
                sessions.append([e])
            else:
                sessions[-1].append(e)

        return [s for s in sessions if len(s) >= 2]

    def _event_to_action(self, event: Event) -> str:
        """Convert an event to a canonical action label."""
        # Combine source + type for a meaningful action label
        if event.event_type in ("said", "command") and event.content:
            # Extract the verb from content
            words = event.content.lower().split()
            if words:
                verb = words[0]
                if verb in ("journal", "search", "note", "help", "look", "go", "use"):
                    return verb
        return f"{event.source}:{event.event_type}"

    def _find_ngrams(
        self, sessions: list[list[str]], n: int
    ) -> list[Prediction]:
        """Find frequent n-grams across all sessions."""
        ngram_counts: Counter[tuple[str, ...]] = Counter()

        for session in sessions:
            for i in range(len(session) - n + 1):
                ngram = tuple(session[i : i + n])
                ngram_counts[ngram] += 1

        predictions = []
        for ngram, count in ngram_counts.most_common(10):
            if count < self.min_frequency:
                break

            sequence_text = " → ".join(ngram)
            confidence = min(0.4 + count * 0.05, 0.85)

            np_ = {"count": str(count), "sequence": sequence_text}
            predictions.append(Prediction(
                id=f"seq-ngram-{uuid.uuid4().hex[:8]}",
                text=t("oracle.sequence.ngram", **np_),
                text_key="oracle.sequence.ngram",
                text_params=np_,
                category=PredictionCategory.SEQUENCE,
                confidence=confidence,
                evidence=f"{n}-gram, frequency={count}, sessions={len(sessions)}",
            ))

        return predictions

    def _predict_next(
        self, sessions: list[list[str]], recent: list[str]
    ) -> list[Prediction]:
        """Given recent actions, predict the most likely next action."""
        if len(recent) < 2:
            return []

        # Build transition probabilities from bigrams
        transitions: dict[str, Counter[str]] = defaultdict(Counter)
        for session in sessions:
            for i in range(len(session) - 1):
                transitions[session[i]][session[i + 1]] += 1

        # Check what usually follows the most recent action
        last_action = recent[-1]
        if last_action not in transitions:
            return []

        total = sum(transitions[last_action].values())
        if total < 3:
            return []

        best_next, best_count = transitions[last_action].most_common(1)[0]
        probability = best_count / total

        if probability < 0.3:
            return []

        confidence = min(0.4 + probability * 0.4, 0.85)

        sp = {
            "last": last_action,
            "next": best_next,
            "probability": f"{probability:.0%}",
        }
        return [Prediction(
            id=f"seq-next-{uuid.uuid4().hex[:8]}",
            text=t("oracle.sequence.next", **sp),
            text_key="oracle.sequence.next",
            text_params=sp,
            category=PredictionCategory.SEQUENCE,
            confidence=confidence,
            evidence=f"Bigram: {last_action}→{best_next}, count={best_count}/{total}",
        )]
