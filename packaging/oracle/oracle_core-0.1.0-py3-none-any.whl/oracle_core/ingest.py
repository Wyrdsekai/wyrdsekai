"""Event ingestion and feature extraction pipeline.

Takes raw events from any source and produces feature vectors for ML models.
The MUD architecture makes this easy — events already have types, timestamps,
rooms, and entities. But oracle-core works with any event source.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Sequence

import numpy as np

from .models import Event


@dataclass
class FeatureVector:
    """Extracted features from one or more events in a time window."""

    window_start: datetime
    window_end: datetime
    event_count: int = 0

    # Temporal features
    hour_of_day: float = 0.0  # 0-23
    day_of_week: float = 0.0  # 0=Monday, 6=Sunday
    week_of_year: float = 0.0
    is_weekend: bool = False

    # Volume features
    events_per_source: dict[str, int] = field(default_factory=dict)
    events_per_type: dict[str, int] = field(default_factory=dict)

    # Text features (from content-bearing events)
    top_keywords: list[str] = field(default_factory=list)
    avg_content_length: float = 0.0
    unique_entities: int = 0

    # Numeric features (from events with numeric_value)
    numeric_mean: float | None = None
    numeric_std: float | None = None
    numeric_min: float | None = None
    numeric_max: float | None = None

    # Activity features
    active_minutes: int = 0  # minutes with at least one event
    gap_minutes: float = 0.0  # avg gap between events
    unique_rooms: int = 0


class FeaturePipeline:
    """Transforms raw events into feature vectors for ML models.

    Operates on time windows (hourly, daily). Each window becomes one
    feature vector. The pipeline is stateless — give it events, get features.
    """

    # Common stopwords for keyword extraction
    STOPWORDS = frozenset(
        "the a an is are was were be been being have has had do does did "
        "will would shall should may might can could this that these those "
        "i me my we our you your he she it they them their its and or but "
        "if in on at to for of with from by as not no".split()
    )

    def extract_daily(self, events: Sequence[Event], date: datetime) -> FeatureVector:
        """Extract features for a single day."""
        day_start = date.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        day_events = [e for e in events if day_start <= e.timestamp < day_end]
        return self._extract(day_events, day_start, day_end)

    def extract_hourly(self, events: Sequence[Event], hour_start: datetime) -> FeatureVector:
        """Extract features for a single hour."""
        hour_end = hour_start + timedelta(hours=1)
        hour_events = [e for e in events if hour_start <= e.timestamp < hour_end]
        return self._extract(hour_events, hour_start, hour_end)

    def extract_windows(
        self, events: Sequence[Event], window_hours: int = 24
    ) -> list[FeatureVector]:
        """Extract features for all windows in the event span."""
        if not events:
            return []

        sorted_events = sorted(events, key=lambda e: e.timestamp)
        start = sorted_events[0].timestamp.replace(minute=0, second=0, microsecond=0)
        end = sorted_events[-1].timestamp

        features = []
        current = start
        delta = timedelta(hours=window_hours)
        while current < end:
            window_events = [e for e in sorted_events if current <= e.timestamp < current + delta]
            if window_events:
                features.append(self._extract(window_events, current, current + delta))
            current += delta

        return features

    def extract_time_series(
        self, events: Sequence[Event], metric: str = "count", window_hours: int = 24
    ) -> tuple[list[datetime], list[float]]:
        """Extract a numerical time series from events.

        Args:
            events: Raw events
            metric: "count" (event count per window), "numeric" (mean numeric_value),
                    "content_length" (mean content length)
            window_hours: Window size in hours

        Returns:
            Tuple of (timestamps, values) suitable for forecasting models.
        """
        if not events:
            return [], []

        sorted_events = sorted(events, key=lambda e: e.timestamp)
        start = sorted_events[0].timestamp.replace(minute=0, second=0, microsecond=0)
        end = sorted_events[-1].timestamp

        timestamps: list[datetime] = []
        values: list[float] = []
        current = start
        delta = timedelta(hours=window_hours)

        while current <= end:
            window_events = [e for e in sorted_events if current <= e.timestamp < current + delta]

            if metric == "count":
                values.append(float(len(window_events)))
            elif metric == "numeric":
                nums = [e.numeric_value for e in window_events if e.numeric_value is not None]
                values.append(float(np.mean(nums)) if nums else 0.0)
            elif metric == "content_length":
                lengths = [len(e.content) for e in window_events if e.content]
                values.append(float(np.mean(lengths)) if lengths else 0.0)
            else:
                values.append(float(len(window_events)))

            timestamps.append(current)
            current += delta

        return timestamps, values

    def _extract(
        self, events: Sequence[Event], window_start: datetime, window_end: datetime
    ) -> FeatureVector:
        """Extract features from a set of events in a time window."""
        fv = FeatureVector(
            window_start=window_start,
            window_end=window_end,
            event_count=len(events),
        )

        if not events:
            return fv

        # Temporal
        mid = window_start + (window_end - window_start) / 2
        fv.hour_of_day = mid.hour + mid.minute / 60.0
        fv.day_of_week = mid.weekday()
        fv.week_of_year = mid.isocalendar()[1]
        fv.is_weekend = mid.weekday() >= 5

        # Volume by source and type
        fv.events_per_source = dict(Counter(e.source for e in events))
        fv.events_per_type = dict(Counter(e.event_type for e in events))

        # Text features
        all_content = " ".join(e.content for e in events if e.content)
        if all_content:
            fv.top_keywords = self._extract_keywords(all_content, n=10)
            lengths = [len(e.content) for e in events if e.content]
            fv.avg_content_length = float(np.mean(lengths)) if lengths else 0.0

        # Entities
        all_entities = set()
        for e in events:
            if e.entity_id:
                all_entities.add(e.entity_id)
        fv.unique_entities = len(all_entities)

        # Numeric
        numerics = [e.numeric_value for e in events if e.numeric_value is not None]
        if numerics:
            arr = np.array(numerics)
            fv.numeric_mean = float(np.mean(arr))
            fv.numeric_std = float(np.std(arr))
            fv.numeric_min = float(np.min(arr))
            fv.numeric_max = float(np.max(arr))

        # Activity
        minutes_with_events = set()
        for e in events:
            minute_key = e.timestamp.replace(second=0, microsecond=0)
            minutes_with_events.add(minute_key)
        fv.active_minutes = len(minutes_with_events)

        if len(events) >= 2:
            sorted_ts = sorted(e.timestamp for e in events)
            gaps = [(sorted_ts[i + 1] - sorted_ts[i]).total_seconds() / 60.0
                    for i in range(len(sorted_ts) - 1)]
            fv.gap_minutes = float(np.mean(gaps))

        fv.unique_rooms = len(set(e.room_id for e in events if e.room_id))

        return fv

    def _extract_keywords(self, text: str, n: int = 10) -> list[str]:
        """Simple keyword extraction via term frequency (no external deps)."""
        words = re.findall(r"[a-zA-Z]{3,}", text.lower())
        filtered = [w for w in words if w not in self.STOPWORDS]
        counts = Counter(filtered)
        return [word for word, _ in counts.most_common(n)]
