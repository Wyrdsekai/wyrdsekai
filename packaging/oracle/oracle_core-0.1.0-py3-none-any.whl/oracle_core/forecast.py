"""Time series forecasting.

Two backends:
- Classical: Fourier decomposition + linear trend (always available, zero deps)
- Chronos: zero-shot foundation model (optional, requires chronos-forecasting + torch)

The engine auto-selects based on what's installed.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Any, Protocol

import numpy as np

from .i18n import t
from .models import ForecastPoint, Prediction, PredictionCategory


class Forecaster(Protocol):
    """Interface for forecasting backends."""

    def forecast(
        self,
        timestamps: list[datetime],
        values: list[float],
        horizon: int,
        label: str,
    ) -> list[Prediction]: ...


class ClassicalForecaster:
    """Fourier decomposition + linear trend forecaster.

    No external dependencies beyond numpy. Decomposes the series into:
    - Linear trend (slope + intercept)
    - Seasonal components (detected via FFT)
    - Residual noise (for confidence intervals)

    Good enough for daily/weekly patterns. No training needed.
    """

    def __init__(self, max_harmonics: int = 3):
        self.max_harmonics = max_harmonics

    def forecast(
        self,
        timestamps: list[datetime],
        values: list[float],
        horizon: int = 14,
        label: str = "activity",
    ) -> list[Prediction]:
        """Forecast the next `horizon` periods.

        Args:
            timestamps: Historical timestamps (evenly spaced assumed)
            values: Historical values
            horizon: Number of periods to forecast
            label: Human-readable label

        Returns:
            List of Predictions with forecast_values.
        """
        if len(values) < 14:
            return []

        arr = np.array(values, dtype=float)
        n = len(arr)
        x = np.arange(n, dtype=float)

        # 1. Detrend: linear regression
        slope, intercept = np.polyfit(x, arr, 1)
        trend = slope * x + intercept
        detrended = arr - trend

        # 2. Find dominant frequencies via FFT
        fft = np.fft.rfft(detrended)
        magnitudes = np.abs(fft)
        freqs = np.fft.rfftfreq(n)

        # Skip DC component (index 0), find top harmonics
        if len(magnitudes) > 1:
            top_indices = np.argsort(magnitudes[1:])[-self.max_harmonics:][::-1] + 1
        else:
            top_indices = np.array([], dtype=int)

        # 3. Reconstruct seasonal component from top harmonics
        seasonal_fft = np.zeros_like(fft)
        for idx in top_indices:
            if magnitudes[idx] > magnitudes[1:].mean():  # only significant harmonics
                seasonal_fft[idx] = fft[idx]

        seasonal = np.fft.irfft(seasonal_fft, n=n)

        # 4. Residual = actual - trend - seasonal → noise estimate
        residual = detrended - seasonal[:n]
        noise_std = float(np.std(residual))

        # 5. Forecast: extend trend + seasonal + confidence interval
        forecast_x = np.arange(n, n + horizon, dtype=float)
        forecast_trend = slope * forecast_x + intercept

        # Extend seasonal (periodic — just tile it)
        if len(seasonal) > 0:
            forecast_seasonal = np.array([seasonal[int(i) % n] for i in forecast_x])
        else:
            forecast_seasonal = np.zeros(horizon)

        forecast_values = forecast_trend + forecast_seasonal

        # Confidence interval widens with distance
        points = []
        last_ts = timestamps[-1]
        # Estimate period between timestamps
        if len(timestamps) >= 2:
            avg_delta = (timestamps[-1] - timestamps[0]) / (len(timestamps) - 1)
        else:
            avg_delta = timedelta(days=1)

        for i in range(horizon):
            ts = last_ts + avg_delta * (i + 1)
            val = float(forecast_values[i])
            # CI widens with sqrt of distance
            ci = noise_std * 1.96 * np.sqrt(1 + i / horizon)
            points.append(ForecastPoint(
                timestamp=ts,
                predicted=val,
                lower_bound=val - ci,
                upper_bound=val + ci,
            ))

        # Determine trend direction for human-readable text
        direction = "increasing" if slope > 0.05 else "declining" if slope < -0.05 else "stable"

        # Detect dominant period
        seasonality = ""
        if top_indices is not None and len(top_indices) > 0:
            dominant_idx = top_indices[0]
            if freqs[dominant_idx] > 0:
                period = 1.0 / freqs[dominant_idx]
                seasonality = t("oracle.forecast.seasonality", period=_period_label(period))

        confidence = min(0.5 + (1.0 - noise_std / (np.std(arr) + 1e-6)) * 0.4, 0.90)
        confidence = max(confidence, 0.3)

        key = f"oracle.forecast.{direction}"
        fp = {
            "label": label,
            "horizon": str(horizon),
            "seasonality": seasonality,
        }
        return [Prediction(
            id=f"forecast-{uuid.uuid4().hex[:8]}",
            text=t(key, **fp),
            text_key=key,
            text_params=fp,
            category=PredictionCategory.FORECAST,
            confidence=confidence,
            evidence=f"Fourier decomposition: slope={slope:.4f}/period, noise_std={noise_std:.2f}, n={n}",
            forecast_values=points,
        )]


class ChronosForecaster:
    """Zero-shot forecasting via Amazon Chronos foundation model.

    Requires the `forecast` extra (chronos-forecasting + torch).
    Uses chronos-bolt-tiny (8M) by default, upgrades to larger models if available.
    """

    def __init__(self, model_name: str = "amazon/chronos-bolt-tiny"):
        self.model_name = model_name
        self._pipeline: Any = None

    def _load(self):
        if self._pipeline is not None:
            return

        try:
            from chronos import ChronosPipeline
            import torch

            self._pipeline = ChronosPipeline.from_pretrained(
                self.model_name,
                device_map="cpu",
                torch_dtype=torch.float32,
            )
        except ImportError:
            raise ImportError(
                "Chronos not installed — this forecaster needs the `forecast` "
                "extra: pip install 'oracle-core[forecast]' "
                "(or pip install '.[forecast]' from a source checkout)"
            )

    def forecast(
        self,
        timestamps: list[datetime],
        values: list[float],
        horizon: int = 14,
        label: str = "activity",
    ) -> list[Prediction]:
        """Zero-shot forecast using Chronos."""
        if len(values) < 10:
            return []

        self._load()

        import torch

        context = torch.tensor(values, dtype=torch.float32).unsqueeze(0)
        forecast_result = self._pipeline.predict(
            context,
            prediction_length=horizon,
            num_samples=20,
        )

        # forecast_result shape: (1, num_samples, horizon)
        samples = forecast_result[0].numpy()  # (num_samples, horizon)
        median = np.median(samples, axis=0)
        lower = np.percentile(samples, 10, axis=0)
        upper = np.percentile(samples, 90, axis=0)

        # Build forecast points
        last_ts = timestamps[-1]
        if len(timestamps) >= 2:
            avg_delta = (timestamps[-1] - timestamps[0]) / (len(timestamps) - 1)
        else:
            avg_delta = timedelta(days=1)

        points = []
        for i in range(horizon):
            ts = last_ts + avg_delta * (i + 1)
            points.append(ForecastPoint(
                timestamp=ts,
                predicted=float(median[i]),
                lower_bound=float(lower[i]),
                upper_bound=float(upper[i]),
            ))

        # Trend from median
        if median[-1] > median[0] * 1.1:
            direction = "increasing"
        elif median[-1] < median[0] * 0.9:
            direction = "declining"
        else:
            direction = "stable"

        spread = float(np.mean(upper - lower))
        # Convert out of numpy scalars once, here; everything downstream is then
        # plain float arithmetic rather than a chain of casts.
        std = float(np.std(values))
        confidence = min(0.7 + (1.0 - spread / (std + 1e-6)) * 0.25, 0.95)
        confidence = max(confidence, 0.5)

        key = f"oracle.forecast.{direction}"
        fp = {
            "label": label,
            "horizon": str(horizon),
            "seasonality": "",
        }
        return [Prediction(
            id=f"forecast-chronos-{uuid.uuid4().hex[:8]}",
            text=t(key, **fp),
            text_key=key,
            text_params=fp,
            category=PredictionCategory.FORECAST,
            confidence=confidence,
            evidence=f"Chronos zero-shot, model={self.model_name}, 80% CI spread={spread:.2f}, n={len(values)}",
            forecast_values=points,
        )]


def get_best_forecaster() -> Forecaster:
    """Auto-select the best available forecaster."""
    try:
        import chronos  # noqa: F401
        import torch  # noqa: F401
        return ChronosForecaster()
    except ImportError:
        return ClassicalForecaster()


def _period_label(periods: float) -> str:
    p = round(periods)
    if p == 1:
        return "daily"
    if p == 7:
        return "weekly"
    if 28 <= p <= 31:
        return "monthly"
    return f"{p}-period"
